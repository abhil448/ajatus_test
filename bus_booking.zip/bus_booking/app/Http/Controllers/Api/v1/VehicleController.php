<?php

namespace App\Http\Controllers\Api\v1;

use App\Http\Controllers\Controller;
use App\Models\Vehicle;
use Illuminate\Http\Request;

class VehicleController extends Controller
{
    public function store(Request $request)
    {
        if(!auth()->user()->role == 'admin')
        {
            
            return response(['message'=>'You are not authorize to do that'],400);
        }else
        {

            $validated = $request->validate([
                'reg_no'     =>'required',
                'axle_no'    =>'required',
                'total_seats'=>'required|integer',
                'bus_type'   =>'required',
                'to_des'     =>'required',
                'from_des'   =>'required',
            ]);
     
            $vehicle = Vehicle::create($validated);

            return response(['message'=>'vehicle successfully added',
                             'data'=>$vehicle->toArray()],200);
        }

    }


    public function update(Request $request,$id)
    {
        if(auth()->user()->role === 'admin'){

            $vehicle = Vehicle::find($id);
           if(!$vehicle){
                return response()->json([
                    'message'=> 'Vehicle not found'
                ],500);
           }
            
           $updated = $vehicle->fill($request->all())->save();
           if($updated){
               return response()->json([
                   'message' => 'product successfully updated',
                   'data'    => $updated->toArray()
               ], 200);
           }else{
            return response()->json([
                'message' => 'product updation failed',
                'data'    => ''
            ], 200);
           }
        }else{
            return response(['message'=>'Your not authenticated to do that'],500);
        }


    }
}
