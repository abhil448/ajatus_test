<?php

namespace App\Http\Controllers\Api\v1;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function register(Request $request)
    {
        $registerData = $request->validate([
            'name'=>'required',
            'email'=>'required|unique:users',
            'password'=>'required|confirmed',
            'mobile'=>'required|integer'
        ]);
        $registerData['password'] = bcrypt($request->password);
        $registerData['role'] = 'user';
        $user = User::create($registerData);
        
        $accessToken = $user->createToken('authToken')->accessToken;

        return response(['user'=> $user,'token'=> $accessToken]);
    }


    public function login(Request $request){

        $loginData = $request->validate([
            'email'=>'required',
            'password'=>'required',
        ]);

        if(!Auth::attempt($loginData)){
            return response(['message'=>'Invalid credential'],500);
        }

        $accessToken = auth()->user()->createToken('authToken')->accessToken;

        return response(['user'=> auth()->user(),'token'=> $accessToken]);
        

    }
    
}
